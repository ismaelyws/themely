<?php
  include("/usr/local/cpanel/php/cpanel.php"); // Instantiate the CPANEL object.
  $cpanel = new CPANEL(); // Connect to cPanel - only do this once.
  print $cpanel->header( "WordPress Installer & Theme Directory <small>by Themely</small>" ); // Add the header.
?>

<!-- OCWPI STYLESHEET -->
<link rel="stylesheet" href="style.css">

<?php
  require "process.php";
  if (isset($_POST['search'])) {
    require "search.php";
  }
?>

<div class="container-fluid ocwpi-content">

  <div class="row">

    <div class="col-sm-9 col-md-10">

      <p class="lead text-muted ocwpi-lead">Use the software that powers over 34% of the web. <a target="_blank" href="https://wordpress.org/">WordPress&trade; is open source software</a> you can use to create a website, blog, or app. Beautiful designs, powerful features, and the freedom to build anything you want. WordPress is both free and priceless at the same time.</p>

    </div>

    <div class="col-sm-3 col-md-1 col-md-offset-1">

      <a class="ocwpi-badge" title="WordPress Logo" href="https://wordpress.org/download/" target="_blank"></a>

    </div>

  </div>

  <div class="body-content">

    <div class="section">

      <div class="row">

        <div class="col-xs-12 col-md-5 col-lg-4 ocwpi-left">

          <div class="row alert alert-dark" role="alert">
            <code><?php echo $progress_message ?></code>
          </div>

          <div class="ocwpi-padding">

            <div class="installation-form">

              <h3>Quick Installation <span class="pull-right small video-tutorial"><span class="glyphicon glyphicon-hd-video" aria-hidden="true"></span> <a href="#" data-toggle="modal" data-target="#VideoTutorialModal"><span class="hidden-xs hidden-md">Watch</span> Video Tutorial</a></span></h3>

              <div class="modal fade" id="VideoTutorialModal" tabindex="-1" role="dialog" aria-labelledby="VideoTutorialModal">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title" id="VideoTutorialModal">How to install WordPress with Themely cPanel Plugin</h4>
                    </div>
                    <div class="modal-body">
                      <iframe width="560" height="315" src="https://www.youtube.com/embed/digtdXBkGWo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" style="max-width: 100% !important;" allowfullscreen></iframe>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>

              <p>Complete the form below to install the latest version of WordPress.</p>

              <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                
                <div class="form-group">
                  <label>Site Name</label>
                  <input type="text" class="form-control" placeholder="Enter site name" name="site_name" value="<?php echo $site_name ?>" tabindex="1" minlength=3>
                  <span class="ocwpi-error small"><?php echo $site_name_error ?></span>
                </div>
                
                <div class="form-group">
                  <label>Site Description</label>
                  <input type="text" class="form-control" placeholder="Enter site description" name="site_description" value="<?php echo $site_description ?>" tabindex="2" minlength=3>
                  <span class="ocwpi-error small"><?php echo $site_description_error ?></span>
                </div>
                
                <div class="form-group">
                  <label>Your new WordPress site URL will be:</label>
                  <pre id="site_url"></pre>
                  <span class="glyphicon glyphicon-asterisk small" aria-hidden="true"></span> <span class="small">To install on another domain, in a directory or sub-domain, click <strong>Advanced Options</strong>.</span>
                </div>
                
                <button id="submit" type="submit" name="submit" class="btn btn-lg btn-primary btn-block">Install WordPress</button>

                <h3><a data-toggle="collapse" href="#advanced" aria-expanded="false" aria-controls="footwear">Advanced Options</a></h3>

                <p>Click to expand the list of options & customize your installation.</p>

                <div id="advanced" class="collapse">

                  <div class="form-group">
                    <label>Admin Username</label>
                    <input type="text" class="form-control" placeholder="Enter admin username" value="ismaelyws" minlength=3>
                    <span class="glyphicon glyphicon-asterisk small" aria-hidden="true"></span> <span class="small">Choosing a username other than <code>admin</code> is a good security measure to help prevent brute force attacks & unauthorized access to your WordPress admin dashboard.</span>
                  </div>

                  <div class="form-group">
                    <label>Admin Password</label>
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Enter a secure 8-12 digit password" rel="gp" data-size="12" data-character-set="a-z,A-Z,0-9,#" minlength=8>
                      <span class="input-group-btn">
                        <button type="button" class="btn btn-default btn-copy js-tooltip js-copy" data-toggle="tooltip" data-placement="top" data-copy="6AYSO|7AWf|t" title="Copy to clipboard">Copy Password</button>
                        <button class="btn btn-default getNewPass" type="button">Generate Password</button>
                      </span>
                    </div>
                  </div>

                  <div class="form-group">
                    <label>Admin Email Address</label>
                    <input type="email" class="form-control" placeholder="Enter admin email address" value="<?php $emails = $cpanel->uapi('Email', 'list_pops', array( 'regex' => 'user', ) ); ?>">
                  </div>

                  <div class="form-group">
                    <label>Web Protocol (with or without www. & SSL or non-SSL)</label>
                    <select name="site_protocol" id="site_protocol" class="form-control">
                      <option value="https://www.">https://www.</option>
                      <option value="https://">https://</option>
                      <option value="http://www.">http://www.</option>
                      <option value="http://">http://</option>                      
                    </select>
                    <span class="glyphicon glyphicon-asterisk small" aria-hidden="true"></span> <span class="small">If you have an SSL certificate installed on your domain we recommend using a secure <code>https</code> protocol.</span>
                  </div>

                  <div class="form-group">
                    <label>Domain or Sub-domain</label>
                    <select name="site_domain" id="site_domain" class="form-control custom-select">
                      <option value="domain.com">domain.com</option>
                      <option value="sub.domain.com">sub.domain.com</option>
                      <option value="domain.domain.com">domain.domain.com</option>
                    </select>
                  </div>
      
                  <div class="form-group">
                    <label for="basic-url">Directory</label>
                    <div class="input-group">
                      <input type="text" id="site_directory" class="form-control">
                      <span class="glyphicon glyphicon-asterisk small" aria-hidden="true"></span> <span class="small">The directory is relative to your domain path and should not already exist. For example, to install WordPress on <code>https://www.mydomain.com/wordpress/</code> just enter <code>wordpress</code>. Otherwise, leave the field empty.</span>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="basic-url">Database Name</label>
                    <div class="input-group">
                      <span class="input-group-addon" id="basic-addon3">database_</span>
                      <input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3" value="wp9" minlength=1>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="basic-url">Database User</label>
                    <div class="input-group">
                      <span class="input-group-addon" id="basic-addon3">user_</span>
                      <input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3" value="wp9" minlength=1>
                    </div>
                  </div>

                  <div class="form-group">
                    <label>Database Table Prefix</label>
                    <div class="input-group" style="width:132px;" >
                      <span class="input-group-addon" id="basic-addon3">wp</span>
                      <input type="text" class="form-control" placeholder="Enter database table prefix" rel="dp" data-size="3" data-character-set="a-z" minlength=1>
                      <span class="input-group-addon" id="basic-addon3">_</span>
                    </div>
                    <span class="glyphicon glyphicon-asterisk small" aria-hidden="true"></span> <span class="small">Instead of using the standard <code>wp_</code> database table prefix; improve WordPress security by setting a custom prefix to help prevent SQL injection attacks.</span>
                  </div>

                </div>

            </form>

            </div>

            <div class="installation-confirmation" style="display:none;">

                <h3>Installation Confirmation</h3>

                <p>You have <span class="text-success"><strong>successfully</strong></span> installed WordPress. Access your new site:</p>

                <label>WordPress Site URL</label>
                <pre><a href="#">https://www.domain.com/</a></pre>

                <label>WordPress Admin Dashboard URL</label>
                <pre><a href="#">https://www.domain.com/wp-admin/</a></pre>

                <label>Admin Username</label>
                <pre>ismaelyws</pre>

                <label>Admin Password</label>
                <pre>2SxAJ#L*yqRC</pre>

                <h3>Getting Started with WordPress</h3>

                <p>First time using WordPress? We've compiled a list of resources that will help you get started <em>managing, customizing and securing</em> your new WordPress site.</p>

                  <ul class="list-group col-md-6">

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/managing-plugins/#finding-and-installing-plugins">Finding & installing plugins</a></li>

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/appearance-menus-screen/#creating-menu">Creating menus</a></li>

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/faq-my-site-was-hacked/">Help, my site was hacked!</a></li>

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/writing-posts/">Writing posts</a></li>

                  </ul>

                  <ul class="list-group col-md-6">

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/pages/#creating-pages">Creating pages</a></li>

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/why-should-i-use-https/">Why should I use HTTPS?</a></li>

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/wordpress-widgets/#displaying-widgets">Displaying widgets</a></li>

                    <li class="list-group-item"><a target="_blank" href="https://wordpress.org/support/article/wordpress-backups/#backing-up-your-wordpress-site">Creating a backup</a></li>

                  </ul>

            </div>

          </div>

        </div>

        <div class="col-xs-12 col-md-7 col-lg-8 ocwpi-right">

          <div class="ocwpi-padding">

            <div class="row">

              <div class="col-sm-12 col-md-12 col-lg-12">

                <h3><span class="hidden-xs hidden-md">Recommended</span> <span class="badge ocwpi-badge-primary">Free</span> <span class="hidden-xs">WordPress</span> Themes <span class="pull-right small contact-support hidden-xs hidden-md"><span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span> Questions? <a target="_blank" href="#">Read FAQ's</a></span><span class="pull-right small contact-support visible-xs visible-md"><span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span> <a target="_blank" href="#">FAQ's</a></span></h3>

              </div>

            </div>

            <div class="row form-group">

              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">

                <p class="text-justify">Select a theme from our directory of <strong>beautiful, secure</strong> and <strong>easy-to-use</strong> WordPress themes from talented developers around the world. Each theme has passed a manual quality & security review by our staff.</p>

              </div>

              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">

                <form onsubmit="return searchThemes();">

                  <div class="input-group">

                    <input type="text" name="search" id="search" class="form-control" placeholder="Search themes...">

                    <span class="input-group-btn">

                      <button class="btn btn-default" type="submit">Search</button>

                    </span>

                  </div>

                </form>

              </div>

            </div>

            <!-- [THEME SEARCH RESULTS] -->
            <div id="results" class="row">                  

              <?php
                $con=mysqli_connect("172.105.27.117", "oneclick_themes", "WRNnjAQuGJSC", "oneclick_themes", "3306");
                if (mysqli_connect_errno()) {
                  echo "<div class='col-md-12'><div class='alert alert-danger'><span class='glyphicon glyphicon-exclamation-sign'></span><div class='alert-message'>Failed to connect to database: " . mysqli_connect_error() . "</div></div></div>";
                }
                $results = mysqli_query($con,"SELECT * FROM themes order by date_listed desc");
                while($row = mysqli_fetch_array($results)) {
                  echo "<div class='col-xs-12 col-sm-6 col-md-6 col-lg-4'>";
                  echo "<div class='thumbnail ocwpi-thumbnail'>";
                  echo "<a href='#'><img src='" . $row['screenshot_url'] . "'></a>";
                  echo "<div class='caption ocwpi-caption'>";
                  echo "<div class='row'>";
                  echo "<div class='col-xs-5 no-padding-right'><span class='ocwpi-name'><strong>" . $row['name'] . "</strong></span><span class='ocwpi-author small'><span class='text-muted'><em>by</em></span> " . $row['author'] . "</span></div>";
                  echo "<div class='col-xs-7 text-right no-padding-left'><a href='" . $row['preview_url'] . "' target='_blank' class='btn btn-sm btn-default' role='button' title='Preview theme'>Preview</a> <a href='#' id='ocwpi-select-theme' class='btn btn-sm btn-default' role='button' title='Select theme'>Select</a></div>";
                  echo "</div>";
                  echo "</div>";
                  echo "</div>";
                  echo "</div>";
                }
                mysqli_close($con);
              ?>

            </div>

          </div>

        </div>
      
      </div>

      <div class="row">

        <div class="col-xs-6 col-sm-6 col-md-8 col-lg-8">

          <p class="ocwpi-footer small">© 2019 inVenture Group DBA Themely. All rights reserved. The <a target="_blank" href="https://wordpress.org/">WordPress</a> name and logo is <a target="_blank" href="http://wordpressfoundation.org/trademark-policy/">trademarked by the WordPress Foundation</a>.</p>

        </div>

        <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">

          <p class="ocwpi-footer small pull-right">Version 1.0.0 &#x00B7; See <a target="_blank" href="CHANGELOG.md">CHANGELOG</a></p>

        </div>

      </div>
    
    </div>
  
  </div>

</div>

<!-- SCRIPTS -->
<script type="text/javascript" src="../libraries/jquery/3.2.0/jquery-3.2.0.js"></script>
<script type="text/javascript" src="../libraries/bootstrap/optimized/js/bootstrap.min.js"></script>
<script type="text/javascript" src="script.js"></script>

<?php
  print $cpanel->footer(); // Add the footer.
  $cpanel->end(); // Disconnect from cPanel - only do this once.
?>