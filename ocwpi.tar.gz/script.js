$("#ocwpi-select-theme").click(function () {
    $(this).text(function(i, v){
       return v === 'Select' ? 'Selected' : 'Select'
    });
    $(this).toggleClass('btn-default').toggleClass('btn-success');
});

/* Generate Secure Password */
function randString(id) {
  var dataSet = $(id).attr('data-character-set').split(',');  
  var possible = '';
  if($.inArray('a-z', dataSet) >= 0){
    possible += 'abcdefghijklmnopqrstuvwxyz';
  }
  if($.inArray('A-Z', dataSet) >= 0){
    possible += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  }
  if($.inArray('0-9', dataSet) >= 0){
    possible += '0123456789';
  }
  if($.inArray('#', dataSet) >= 0){
    possible += '![]{}()%&*$#^<>~@|';
  }
  var text = '';
  for(var i=0; i < $(id).attr('data-size'); i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
} // Create a new password on page load
  $('input[rel="gp"]').each(function(){
    $(this).val(randString($(this)));
  });
  // Create a new password
  $(".getNewPass").click(function(){
    var field = $(this).closest('div').find('input[rel="gp"]');
    field.val(randString(field));
  });
  // Auto Select Password On Focus
  $('input[rel="gp"]').on("click", function () {
     $(this).select();
  });
  // Create a new DB prefix on page load
  $('input[rel="dp"]').each(function() {
    $(this).val(randString($(this)));
  });
  // Auto Select DB Prefix On Focus
  $('input[rel="dp"]').on("click", function () {
     $(this).select();
});

/* Display Site URL */
$(document).ready(DisplaySiteURL);
function DisplaySiteURL() {
    var site_url = $("#site_protocol").val();
    site_url += $("#site_domain").val();
    if( $("#site_directory").val() ) {
      site_url += '&#47;';
      site_url += $("#site_directory").val();
    };
    $("#site_url").html(site_url);
    $("#site_admin_url").html(site_url + '/wp-admin/');
} $(function() {
    $("#site_protocol").change(function() {
      DisplaySiteURL()
    });
    $("#site_domain").change(function() {
      DisplaySiteURL();
    });
    $("#site_directory").keyup(function() {
      DisplaySiteURL();
    });
});

/* Copy to Clipboard */
// Attempts to use .execCommand('copy') on a created text field
// Falls back to a selectable alert if not supported
// Attempts to display status in Bootstrap tooltip
// Source: https://codepen.io/nathanlong/pen/ZpAmjv
function copyToClipboard(text, el) {
  var copyTest = document.queryCommandSupported('copy');
  var elOriginalText = el.attr('data-original-title');
  if (copyTest === true) {
    var copyTextArea = document.createElement("textarea");
    copyTextArea.value = text;
    document.body.appendChild(copyTextArea);
    copyTextArea.select();
    try {
      var successful = document.execCommand('copy');
      var msg = successful ? 'Copied!' : 'Whoops, not copied!';
      el.attr('data-original-title', msg).tooltip('show');
    } catch (err) {
      console.log('Oops, unable to copy');
    }
    document.body.removeChild(copyTextArea);
    el.attr('data-original-title', elOriginalText);
  } else {
    // Fallback if browser doesn't support .execCommand('copy')
    window.prompt("Copy to clipboard: Ctrl+C or Command+C, Enter", text);
  }
} $(document).ready(function() {
  // Tooltips
  // Requires Bootstrap 3 for functionality
  $('.js-tooltip').tooltip();
  // Copy to clipboard
  // Grab any text in the attribute 'data-copy' and pass it to the copy function
  $('.js-copy').click(function() {
    var text = $(this).attr('data-copy');
    var el = $(this);
    copyToClipboard(text, el);
  });
});

/* Live Search Themes */
function searchThemes() {
  // GET SEARCH TERM
  var data = new FormData();
  data.append('search', document.getElementById("search").value);
  data.append('ajax', 1);

  // AJAX
  var xhr = new XMLHttpRequest();
  xhr.open('POST', "search.php", true);
  xhr.onload = function () {
    if (xhr.status==403 || xhr.status==404) {
      alert("Error loading file!");
    } else {
      var results = JSON.parse(this.response),
          wrapper = document.getElementById("results");
      wrapper.innerHTML = "";
      if (results.length > 0) {
        for(var res of results) {
          var line = document.createElement("article");
          line.innerHTML = "<div class='col-xs-12 col-sm-6 col-md-6 col-lg-4'><div class='thumbnail ocwpi-thumbnail'><a href='#'><img src='" + res['screenshot_url'] + "'></a><div class='caption ocwpi-caption'><div class='row'><div class='col-xs-5 no-padding-right'><span class='ocwpi-name'><strong>" + res['name'] + "</strong></span><span class='ocwpi-author small'><span class='text-muted'><em>by</em></span> " + res['author'] + "</span></div><div class='col-xs-7 text-right no-padding-left'><a href='" + res['preview_url'] + "' target='_blank' class='btn btn-sm btn-default' role='button' title='Preview theme'>Preview</a> <a href='#' id='ocwpi-select-theme' class='btn btn-sm btn-default' role='button' title='Select theme'>Select</a></div></div></div></div></div>";
          wrapper.appendChild(line);
        }
      } else {
        wrapper.innerHTML = "<div class='col-md-12'><div class='alert alert-danger'><span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span><div class='alert-message'><strong>No themes found</strong> - try again with a different search term.</div</div></div>";
      }
    }
  };
  xhr.send(data);
  return false;
} $('#search').blur(function() {
    if( !$(this).val() ) {
          searchThemes();
    }
});