<?php

// define variables and set to empty values
$site_name_error = $site_description_error = "";
$site_name = $site_description = "";
$progress_message = "A robot will now install WordPress for you ;)";

// form is submitted with POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {

	// site name
	if (empty($_POST["site_name"])) {
		$site_name_error = "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span> Site name is required";
	} else {
		$site_name = test_input($_POST["site_name"]);
		// check if site name only consists of letters, numbers and wite space
		if (!preg_match("/^[a-zA-Z0-9 \s]+$/", $site_name)) {
			$site_name_error = "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span> Only letters, numbers and spaces allowed";
		}
	}

	// site description
	if (empty($_POST["site_description"])) {
		$site_description_error = "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span> Site description is required";
	} else {
		$site_description = test_input($_POST["site_description"]);
		// check if site name only consists of letters, numbers and wite space
		if (!preg_match("/^[a-zA-Z0-9 \s]+$/", $site_description)) {
			$site_description_error = "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span> Only letters, numbers and spaces allowed";
		}
	}

	// download and extract latest WordPress version
	// assuming file.zip is in the same directory as the executing script.
	$file = 'https://wordpress.org/latest.zip';
	$newfile = 'wordpress.zip';

	// get the absolute path to $file
	$path = pathinfo(realpath($newfile), ".");

	$zip = new ZipArchive;
	$res = $zip->open($newfile);
	if ($res === TRUE) {
	  // extract it to the path we determined above
	  $zip->extractTo($path);
	  $zip->close();
	  $progress_message = "WordPress successfully extracted";
	} else {
	  $progress_message = "WordPress extraction failed";
	}

}

function test_input($data) {
	$data = trim($data);
	$data = stripcslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

// create mysql database
// https://steemit.com/utopian-io/@javapoint/php-script-to-create-database-automatically-using-php-and-mysqli

?>